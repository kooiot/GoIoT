return {
	version = "1.0",
	build = 'build01',
	product = 'OpenGate',
	desc = 'OpenGate system',
	manufactor = 'SymTech Inc.',
}
