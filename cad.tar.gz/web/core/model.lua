local _M = {}

_M.load = function(app, env)
	--- fake for now
	return env
end

return _M
