return {
	name = 'logs',
	version = "1.0",
	build = 'build01',
	product = 'logs',
	desc = 'logs saving application',
	web = true,
	manufactor = 'OpenGate',
}
