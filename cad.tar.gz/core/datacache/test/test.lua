local db = require 'db'
local o = db.new()

o:open('tttt')
