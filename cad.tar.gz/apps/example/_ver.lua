return	{
	name = 'example',
	desc = 'example io application',
	version = "1.0",
	build = 'build01',
	author='cch',
	manufactor = 'OpenGate',
	path='master/example',
	type = 'app.io',
	depends = {},
	web = true,
}
